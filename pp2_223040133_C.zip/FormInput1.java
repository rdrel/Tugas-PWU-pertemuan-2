import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormInput1 extends JFrame {
    private JTextField nameField;
    private JTextArea addressArea;
    private JRadioButton maleRadio;
    private JRadioButton femaleRadio;
    private JCheckBox subscribeCheck;
    private JComboBox<String> countryCombo;
    private JButton submitButton;
    private JTable table;
    private DefaultTableModel tableModel;

    public FormInput1() {
        setTitle("Form Input 1");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Input Form
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(0, 2));

        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Address:"));
        addressArea = new JTextArea(3, 20);
        inputPanel.add(new JScrollPane(addressArea));

        inputPanel.add(new JLabel("Gender:"));
        JPanel genderPanel = new JPanel();
        maleRadio = new JRadioButton("Male");
        femaleRadio = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        inputPanel.add(genderPanel);

        inputPanel.add(new JLabel("Subscribe:"));
        subscribeCheck = new JCheckBox();
        inputPanel.add(subscribeCheck);

        inputPanel.add(new JLabel("Country:"));
        countryCombo = new JComboBox<>(new String[]{"Select", "USA", "Canada", "UK"});
        inputPanel.add(countryCombo);

        submitButton = new JButton("Submit");
        inputPanel.add(submitButton);

        add(inputPanel, BorderLayout.NORTH);

        // Table
        String[] columnNames = {"Name", "Address", "Gender", "Subscribe", "Country"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String address = addressArea.getText();
                String gender = maleRadio.isSelected() ? "Male" : "Female";
                boolean subscribe = subscribeCheck.isSelected();
                String country = (String) countryCombo.getSelectedItem();

                tableModel.addRow(new Object[]{name, address, gender, subscribe, country});

                // Clear fields after submission
                nameField.setText("");
                addressArea.setText("");
                genderGroup