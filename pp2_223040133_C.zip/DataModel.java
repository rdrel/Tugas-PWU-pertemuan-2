import javax.swing.table.DefaultTableModel;

public class DataModel extends DefaultTableModel {
    private String[] columnNames = {"Name", "Address", "Gender", "Subscribe", "Country"};

    public DataModel() {
        super(new Object[][]{}, columnNames);
    }

    public boolean isCellEditable(int row, int column) {
        return false; // Prevent editing of cells
    }
}