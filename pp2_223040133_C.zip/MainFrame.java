import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private JMenuBar menuBar;
    private JMenu menu;
    private JMenuItem form1Item;
    private JMenuItem form2Item;

    public MainFrame() {
        setTitle("Aplikasi Pengelolaan Data");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        menuBar = new JMenuBar();
        menu = new JMenu("Menu");
        form1Item = new JMenuItem("Form Input 1");
        form2Item = new JMenuItem("Form Input 2");

        menu.add(form1Item);
        menu.add(form2Item);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        form1Item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new FormInput1().setVisible(true);
            }
        });

        form2Item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new FormInput2().setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }
}