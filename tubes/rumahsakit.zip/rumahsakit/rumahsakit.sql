-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Feb 2022 pada 08.46
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumahsakit`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_dokter`
--

CREATE TABLE `darel_tb_dokter` (
  `darel_id_dokter` varchar(50) NOT NULL,
  `darel_nama_dokter` varchar(100) NOT NULL,
  `darel_spesialis` varchar(100) NOT NULL,
  `darel_alamat` text NOT NULL,
  `darel_no_telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_dokter`
--

INSERT INTO `darel_tb_dokter` (`darel_id_dokter`, `darel_nama_dokter`, `darel_spesialis`, `darel_alamat`, `darel_no_telp`) VALUES
('8de1a500-3663-457b-9a27-1644e0c17fa2', 'Dokter A', 'Penyakit Dalam', 'Pati', '088200110016'),
('e6bfe5eb-02b5-4ec1-b7f7-ce2e41547700', 'Dr. Yudi saputra', 'Penyakit Kulit', 'Kudus', '081275121552');

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_obat`
--

CREATE TABLE `darel_tb_obat` (
  `darel_id_obat` varchar(50) NOT NULL,
  `darel_nama_obat` varchar(100) NOT NULL,
  `darel_ket_obat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_obat`
--

INSERT INTO `darel_tb_obat` (`darel_id_obat`, `darel_nama_obat`, `darel_ket_obat`) VALUES
('403abc2b-2ef9-4a4e-96d2-b4d83a6a4d2b', 'Obat A', 'obat pusing'),
('43288b0b-661f-44ab-a86d-e149a1c529a9', 'Obat D', '-'),
('4d328bb7-8e21-4812-9686-cbfee056f0f3', 'obat C', 'sakit gigi'),
('e2ea0e7e-04cf-4b41-8a87-04add912f993', 'obat B', 'obat demam');

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_pasien`
--

CREATE TABLE `darel_tb_pasien` (
  `darel_id_pasien` varchar(50) NOT NULL,
  `darel_nomor_identitas` varchar(100) NOT NULL,
  `darel_nama_pasien` varchar(100) NOT NULL,
  `darel_jenis_kelamin` enum('L','P') NOT NULL,
  `darel_alamat` text NOT NULL,
  `darel_no_telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_pasien`
--

INSERT INTO `darel_tb_pasien` (`darel_id_pasien`, `darel_nomor_identitas`, `darel_nama_pasien`, `darel_jenis_kelamin`, `darel_alamat`, `darel_no_telp`) VALUES
('118725fd-44e9-493a-bade-8d0d80040d86', '202012345', 'M. Nur', 'L', 'Pati', '0888123123'),
('1e043aff-3a59-427b-ba7b-b077da8af57a', '111111', 'Rizky', 'L', 'Bandung', '081221334'),
('234123', '1222', 'Budi', 'L', 'Bandung', '08111222'),
('31fc8a27-c69a-460b-8bd7-2e4221a3293f', '202012348', 'Tuyem', 'P', 'Kediri', '0888123126'),
('329845e8-fe19-4785-bf9b-32f1d890e5fd', '20200101', 'Pasien A', 'L', 'Kudus', '088200110017'),
('8894cd57-f38e-4744-bf01-7dded32c42f9', '12231', 'darel', 'L', 'jawa barat', '0812221'),
('8aa4bdb9-5d2d-46cb-b641-1d367bbf6f1d', '202012347', 'Angga', 'L', 'Kudus', '0888123125'),
('c78a88d6-1483-467a-b692-aaa2955645e5', '202012346', 'Andhan', 'L', 'Kudus', '0888123124'),
('e6a304c2-1f05-417e-bf0d-f2672de52229', '021321434', 'Andi', 'L', 'Jl. Satu Kudus', '088200110011');

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_poliklinik`
--

CREATE TABLE `darel_tb_poliklinik` (
  `darel_id_poli` varchar(50) NOT NULL,
  `darel_nama_poli` varchar(100) NOT NULL,
  `darel_lokasi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_poliklinik`
--

INSERT INTO `darel_tb_poliklinik` (`darel_id_poli`, `darel_nama_poli`, `darel_lokasi`) VALUES
('0e4998e7-4876-4d01-8cfd-839fe838b5f4', 'Poli 1', 'K, lt 4'),
('1632b926-4fb4-4d91-b449-f3c648b1f688', 'Poli 3', 'K, lt 6'),
('1c6922c0-d4af-4c1e-869e-2b0b258a8681', '122', '122'),
('9b5ce7e9-a400-40e4-90cd-8134dc8009ca', 'Poli 2', 'K, lt 5');

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_rekammedis`
--

CREATE TABLE `darel_tb_rekammedis` (
  `darel_id_rm` varchar(50) NOT NULL,
  `darel_tgl_periksa` date NOT NULL,
  `darel_id_poli` varchar(50) NOT NULL,
  `darel_id_pasien` varchar(50) NOT NULL,
  `darel_keluhan` text NOT NULL,
  `darel_id_dokter` varchar(50) NOT NULL,
  `darel_diagnosa` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_rekammedis`
--

INSERT INTO `darel_tb_rekammedis` (`darel_id_rm`, `darel_tgl_periksa`, `darel_id_poli`, `darel_id_pasien`, `darel_keluhan`, `darel_id_dokter`, `darel_diagnosa`) VALUES
('3741e036-b8e3-4505-aba1-2d0268afb427', '2022-02-23', '0e4998e7-4876-4d01-8cfd-839fe838b5f4', 'c78a88d6-1483-467a-b692-aaa2955645e5', '<p>ffff</p>\r\n', 'e6bfe5eb-02b5-4ec1-b7f7-ce2e41547700', 'fff'),
('a10e8fd2-afaf-4877-a73c-1d10a869d116', '2022-02-22', '9b5ce7e9-a400-40e4-90cd-8134dc8009ca', '234123', '<p>mual dan meriang</p>\r\n', '8de1a500-3663-457b-9a27-1644e0c17fa2', 'Kurang istirahat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_rm_obat`
--

CREATE TABLE `darel_tb_rm_obat` (
  `darel_id` int(10) NOT NULL,
  `darel_id_rm` varchar(50) NOT NULL,
  `darel_id_obat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_rm_obat`
--

INSERT INTO `darel_tb_rm_obat` (`darel_id`, `darel_id_rm`, `darel_id_obat`) VALUES
(18, 'a10e8fd2-afaf-4877-a73c-1d10a869d116', '403abc2b-2ef9-4a4e-96d2-b4d83a6a4d2b'),
(20, '3741e036-b8e3-4505-aba1-2d0268afb427', '403abc2b-2ef9-4a4e-96d2-b4d83a6a4d2b');

-- --------------------------------------------------------

--
-- Struktur dari tabel `darel_tb_user`
--

CREATE TABLE `darel_tb_user` (
  `darel_id_user` varchar(50) NOT NULL,
  `darel_nama_user` varchar(50) NOT NULL,
  `darel_username` varchar(50) NOT NULL,
  `darel_password` varchar(50) NOT NULL,
  `darel_level` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `darel_tb_user`
--

INSERT INTO `darel_tb_user` (`darel_id_user`, `darel_nama_user`, `darel_username`, `darel_password`, `darel_level`) VALUES
('', 'Yola', 'yola1996', 'a9573217994b9a6b35bce220e5a670a86a2b8b4f', '1'),
('98731216336846848', 'Arif Rusman', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '1');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `darel_tb_dokter`
--
ALTER TABLE `darel_tb_dokter`
  ADD PRIMARY KEY (`darel_id_dokter`),
  ADD KEY `id_dokter` (`darel_id_dokter`);

--
-- Indeks untuk tabel `darel_tb_obat`
--
ALTER TABLE `darel_tb_obat`
  ADD PRIMARY KEY (`darel_id_obat`);

--
-- Indeks untuk tabel `darel_tb_pasien`
--
ALTER TABLE `darel_tb_pasien`
  ADD PRIMARY KEY (`darel_id_pasien`),
  ADD KEY `id_pasien` (`darel_id_pasien`);

--
-- Indeks untuk tabel `darel_tb_poliklinik`
--
ALTER TABLE `darel_tb_poliklinik`
  ADD PRIMARY KEY (`darel_id_poli`),
  ADD KEY `id_poli` (`darel_id_poli`);

--
-- Indeks untuk tabel `darel_tb_rekammedis`
--
ALTER TABLE `darel_tb_rekammedis`
  ADD PRIMARY KEY (`darel_id_rm`),
  ADD KEY `tb_rekammedis_ibfk_1` (`darel_id_pasien`),
  ADD KEY `tb_rekammedis_ibfk_2` (`darel_id_dokter`),
  ADD KEY `tb_rekammedis_ibfk_3` (`darel_id_poli`);

--
-- Indeks untuk tabel `darel_tb_rm_obat`
--
ALTER TABLE `darel_tb_rm_obat`
  ADD PRIMARY KEY (`darel_id`),
  ADD KEY `id_rm` (`darel_id_rm`),
  ADD KEY `id_obat` (`darel_id_obat`);

--
-- Indeks untuk tabel `darel_tb_user`
--
ALTER TABLE `darel_tb_user`
  ADD PRIMARY KEY (`darel_id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `darel_tb_rm_obat`
--
ALTER TABLE `darel_tb_rm_obat`
  MODIFY `darel_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `darel_tb_rekammedis`
--
ALTER TABLE `darel_tb_rekammedis`
  ADD CONSTRAINT `darel_tb_rekammedis_ibfk_1` FOREIGN KEY (`darel_id_pasien`) REFERENCES `darel_tb_pasien` (`darel_id_pasien`),
  ADD CONSTRAINT `darel_tb_rekammedis_ibfk_2` FOREIGN KEY (`darel_id_dokter`) REFERENCES `darel_tb_dokter` (`darel_id_dokter`),
  ADD CONSTRAINT `darel_tb_rekammedis_ibfk_3` FOREIGN KEY (`darel_id_poli`) REFERENCES `darel_tb_poliklinik` (`darel_id_poli`);

--
-- Ketidakleluasaan untuk tabel `darel_tb_rm_obat`
--
ALTER TABLE `darel_tb_rm_obat`
  ADD CONSTRAINT `darel_tb_rm_obat_ibfk_1` FOREIGN KEY (`darel_id_rm`) REFERENCES `darel_tb_rekammedis` (`darel_id_rm`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `darel_tb_rm_obat_ibfk_2` FOREIGN KEY (`darel_id_obat`) REFERENCES `darel_tb_obat` (`darel_id_obat`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
