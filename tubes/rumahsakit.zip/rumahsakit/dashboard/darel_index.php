<?php include_once('../darel_header.php');
$total_pasien = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(darel_nama_pasien) as total_pasien FROM darel_tb_pasien"));
$total_dokter = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(darel_nama_dokter) as total_dokter FROM darel_tb_dokter"));
$total_poli = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(darel_nama_poli) as total_poli FROM darel_tb_poliklinik"));
$total_rekammedis = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(darel_id_rm) as total_rekammedis FROM darel_tb_rekammedis"));
$total_jenis_obat = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(darel_nama_obat) as total_jenis_obat FROM darel_tb_obat"));
?>

<head>
    <style>
        .card {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #d1d1d1;
        }
        .shadow{
            box-shadow: 0px 5px 10px rgba(0,0,0, 0.1);
        }
    </style>
</head>
<div class="row">
    <div class="col-lg-12 bg-black">
        <button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
    </div>
    <div class="col-lg-12 text-center">
        <h1>Dashboard</h1>
        <p>
            Halo <b><?= $_SESSION['user']; ?></b>, 
            selamat datang di website Rumah Sakit (Rekam Medis)
        </p>
    </div>
</div>

<div class="container" style="margin-top: 20px">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6 text-center">
            <div class="card shadow">
                <div class="card-body">
                    Jumlah Dokter
                    <h1>
                        <?= $total_dokter['total_dokter'] ?>
                    </h1>
                    <a href="<?= base_url('dokter/darel_data.php') ?>" class="btn btn-primary"> Lihat Data Dokter</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 text-center">
            <div class="card shadow">
                <div class="card-body">
                    Jumlah Poliklinik
                    <h1>
                        <?= $total_poli['total_poli'] ?>
                    </h1>
                    <a href="<?= base_url('poliklinik/darel_data.php') ?>" class="btn btn-primary"> Lihat Data
                        Poliklinik</a>
                </div>
            </div>
        </div>
        <?php if ($_SESSION['role'] == '1'): ?>
            <div class="col-lg-4 col-md-6 text-center">
                <div class="card shadow">
                    <div class="card-body">
                        Jumlah Pasien
                        <h1>
                            <?= $total_pasien['total_pasien'] ?>
                        </h1>
                        <a href="<?= base_url('pasien/darel_data.php') ?>" class="btn btn-primary"> Lihat Data Pasien</a>
                    </div>
                </div>
            </div>
        <?php endif ?>
        <div class="col-lg-4 col-md-6 text-center">
            <div class="card shadow">
                <div class="card-body">
                    Jumlah Jenis Obat
                    <h1>
                        <?= $total_jenis_obat['total_jenis_obat'] ?>
                    </h1>
                    <a href="<?= base_url('obat/darel_data.php') ?>" class="btn btn-primary"> Lihat Data Obat</a>
                </div>
            </div>
        </div>
        <?php if ($_SESSION['role'] == '1'): ?>
            <div class="col-lg-4 col-md-6 text-center">
                <div class="card shadow">
                    <div class="card-body">
                        Jumlah Rekam Medis
                        <h1>
                            <?= $total_rekammedis['total_rekammedis'] ?>
                        </h1>
                        <a href="<?= base_url('dokter/darel_data.php') ?>" class="btn btn-primary"> Lihat Data Rekam
                            Medis</a>
                    </div>
                </div>
            </div>
        <?php endif ?>
    </div>
</div>


<?php include_once('../darel_footer.php'); ?>