<?php include_once('../darel_header.php'); ?>

<div class="box">
	<div class="col-lg-12 bg-black">
        <button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
    </div>
	<h1>Poliklinik</h1>
	<h4>
		<small>Tambah Data Poliklinik</small>
		<div class="pull-right">
			<a href="darel_data.php" class="btn btn-info btn-xs"> Data</a>
			<a href="darel_generate.php" class="btn btn-info btn-xs"> Tambah data lagi</a>
		</div>
	</h4>
	<div class="row">
		<div class="col-lg-8 col-lg-offset-2">
			<form action="darel_proses.php" method="post">
				<input type="hidden" name="total" value="<?= @$_POST['count_add']; ?>">
				<table class="table">
					<tr>
						<th>#</th>
						<th>Nama Poliklinik</th>
						<th>Lokasi</th>
					</tr>
					<?php
					for($i=1; $i<=$_POST['count_add']; $i++){ ?>
						<tr>
							<td><?= $i; ?></td>
							<td>
								<input type="text" name="nama-<?= $i; ?>" class="form-control" required>
							</td>
							<td>
								<input type="text" name="lokasi-<?= $i; ?>" class="form-control" required>
							</td>
						</tr>
					<?php
					}
					?>
				</table>
				<div class="form-group">
					<input type="submit" name="add" value="Simpan Semua" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>
</div>

<?php include_once('../darel_footer.php'); ?>