<?php
$chk = $_POST['checked'];
if(!isset($chk)){
	echo "<script>alert('Tidak ada data yang dipilih'); window.location='data.php';</script>";
}
else{
	include_once('../darel_header.php'); ?>
	<div class="box">
		<div class="col-lg-12 bg-black">
        <button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
    </div>
		<h1>Poliklinik</h1>
		<h4>
			<small>Edit Data Poliklinik</small>
			<div class="pull-right">
				<a href="darel_data.php" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-chevron-left"></i> Kembali</a>
			</div>
		</h4>
		<div class="row">
			<div class="col-lg-8 col-lg-offset-2">
				<form action="darel_proses.php" method="post">
					<input type="hidden" name="total" value="<?= @$_POST['count_add']; ?>">
					<table class="table">
						<tr>
							<th>#</th>
							<th>Nama Poliklinik</th>
							<th>Lokasi</th>
						</tr>
						<?php
						$no = 1;
						foreach($chk as $id){
							$sql_poli = mysqli_query($con, "SELECT * FROM darel_tb_poliklinik WHERE darel_id_poli='$id'") or die(mysqli_error($con));
							while($data = mysqli_fetch_array($sql_poli)){ ?>
								<tr>
									<td><?= $no++; ?></td>
									<td>
										<input type="hidden" name="id[]" value="<?= $data['darel_id_poli']; ?>">
										<input type="text" name="nama[]" value="<?= $data['darel_nama_poli'] ?>" class="form-control" required>
									</td>
									<td>
										<input type="text" name="lokasi[]" value="<?= $data['darel_lokasi'] ?>" class="form-control" required>
									</td>
								</tr>
							<?php
							}
						}
						?>
					</table>
					<div class="form-group">
						<input type="submit" name="edit" value="Simpan Semua" class="btn btn-success">
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php
	include_once('../darel_footer.php');
} ?>