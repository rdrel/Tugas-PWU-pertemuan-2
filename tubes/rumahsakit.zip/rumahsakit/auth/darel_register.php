<?php
require_once "../_config/darel_config.php";
require "../_assets/libs/vendor/autoload.php";

use Ramsey\Uuid\Uuid;

if (isset($_SESSION['user'])) {
    echo "<script>window.location='" . base_url() . "'</script>";
} else {
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Daftar - Rumah Sakit</title>
        <!-- Bootstrap Core CSS -->
        <link href="<?= base_url(); ?>/_assets/css/bootstrap.min.css" rel="stylesheet">
        <style>
            .back {
                background: #f8f8f8;
                width: 100%;
                position: absolute;
                top: 0;
                bottom: 0;
            }

            .div-center {
                width: 400px;
                height: 400px;
                background-color: #fff;
                position: absolute;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                margin: auto;
                max-width: 100%;
                max-height: 100%;
                overflow: auto;
                padding: 1em 2em;
                border-bottom: 2px solid #ccc;
                display: table;
            }

            div.content {
                display: table-cell;
                vertical-align: middle;
            }
        </style>

    </head>

    <body>

        <div class="back">
            <div class="div-center">
                <div class="content">
                    <h2 class="text-primary text-center"><b>Daftar Rumah Sakit</b></h2>
                    <hr />
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="hidden" name="identitas" id="identitas" class="form-control"
                                value="<?= rand(100000, 999999) ?>">
                        </div>
                        <div class="form-group">
                            <label for="nama">Nama Lengkap</label>
                            <input type="text" name="nama" id="nama" class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label for="jk">Jenis Kelamin</label>
                            <div>
                                <label class="radio-inline">
                                    <input type="radio" name="jk" id="jk" value="L" required=""> Laki - laki
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="jk" value="P"> Perempuan
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <textarea name="alamat" id="alamat" class="form-control" required=""></textarea>
                        </div>
                        <div class="form-group">
                            <label for="telp">No. Telepon</label>
                            <input type="number" name="telp" id="telp" class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="user" class="form-control" placeholder="Username" required=""
                                autofocus="">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="pass" class="form-control" placeholder="Password" required="">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" name="daftar">Daftar</button>
                        <hr />
                        <center><button type="button" class="btn btn-link"><a href="darel_login.php">Sudah punya akun? Masuk
                                    disini</a></button></center>
                    </form>
                </div>
                </span>
            </div>


            <div id="wrapper">
                <div class="container">
                    <div>
                        <div class="row justify-content-center">
                            <?php
                            if (isset($_POST['daftar'])) {
                                $user = trim(mysqli_real_escape_string($con, $_POST['user']));
                                $pass = md5($_POST['pass']);
                                $no_id = $_POST['identitas'];
                                $nama = $_POST['nama'];
                                $jk = $_POST['jk'];
                                $alamat = $_POST['alamat'];
                                $telp = $_POST['telp'];
                                $uuid = Uuid::uuid4()->toString();

                                $insert_pasien = mysqli_query($con, "INSERT INTO darel_tb_pasien VALUES('$uuid', '$no_id', '$nama', '$jk', '$alamat', '$telp')");
                                $insert_user = mysqli_query($con, "INSERT INTO darel_tb_user VALUES('$uuid', '$nama', '$user', '$pass', '2')");
                                if ($insert_user) {
                                    echo "<script>alert('Berhasil Daftar'); window.location='" . base_url('auth/darel_login.php') . "'</script>";
                                }
                            }
                            ?>
                        </div>


                    </div>
                </div>
            </div>

            <script src="<?= base_url('_assets/js/jquery.js'); ?>"></script>
            <script src="<?= base_url('_assets/js/bootstrap.min.js'); ?>"></script>

    </body>

    </html>

<?php } ?>