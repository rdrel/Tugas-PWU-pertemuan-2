<?php
require_once "../_config/darel_config.php";

if (isset($_SESSION['user'])) {
    echo "<script>window.location='" . base_url('dashboard/darel_index.php') . "'</script>";
} else {
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Login - Rumah Sakit</title>
        <!-- Bootstrap Core CSS -->
        <link href="<?= base_url(); ?>/_assets/css/bootstrap.min.css" rel="stylesheet">
        <style>
            .back {
                background: #f8f8f8;
                width: 100%;
                position: absolute;
                top: 0;
                bottom: 0;
            }

            .div-center {
                width: 400px;
                height: 400px;
                background-color: #fff;
                position: absolute;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                margin: auto;
                max-width: 100%;
                max-height: 100%;
                overflow: auto;
                padding: 1em 2em;
                border-bottom: 2px solid #ccc;
                display: table;
            }

            div.content {
                display: table-cell;
                vertical-align: middle;
            }
        </style>

    </head>

    <body>

        <div class="back">
            <div class="div-center">
                <div class="content">
                    <h2 class="text-primary text-center"><b>Rumah Sakit</b></h2>
                    <?php
                            if (isset($_POST['login'])) {
                                $user = trim(mysqli_real_escape_string($con, $_POST['user']));
                                $pass = md5($_POST['pass']);

                                $sql_login = mysqli_query($con, "SELECT * FROM darel_tb_user WHERE darel_username = '$user' AND darel_password = '$pass'") or die(mysqli_error($con));

                                if (mysqli_num_rows($sql_login) > 0) {
                                    $data_hasil = mysqli_fetch_assoc($sql_login);
                                    $role = $data_hasil['darel_level'];  
                                    $id_user = $data_hasil['darel_id_user'];  
                                    $_SESSION['user'] = $user;
                                    $_SESSION['role'] = $role;
                                    $_SESSION['id_user'] = $id_user;
                                    echo "<script>window.location='" . base_url('dashboard/darel_index.php') . "'</script>";

                                } else { ?>
                                    
                                            <div class="alert alert-danger alert-dismissable" role="alert">
                                                <button href="#" class="close" data-dismiss="alert"
                                                    aria-label="close">&times;</button>
                                                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                                Username / Password salah
                                            </div>
                                    <?php
                                }
                            }
                            ?>
                    <hr />
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Username</label>
                            <input type="text" name="user" class="form-control" id="exampleInputEmail1" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name="pass" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" name="login">Login</button>
                        <hr />
                        <center><button type="button" class="btn btn-link"><a href="darel_register.php">Tidak punya akun? Daftar disini</a></button></center>
                    </form>
                </div>
                </span>
            </div>

            <script src="<?= base_url('_assets/js/jquery.js'); ?>"></script>
            <script src="<?= base_url('_assets/js/bootstrap.min.js'); ?>"></script>

    </body>

    </html>

<?php } ?>