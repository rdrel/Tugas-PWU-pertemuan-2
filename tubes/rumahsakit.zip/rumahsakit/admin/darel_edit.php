<?php
include_once('../darel_header.php');
?>

<div class="box">
	<div class="col-lg-12 bg-black">
        <button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
    </div>
	<h1>Dokter</h1>
	<h4>
		<small>Edit Data Dokter</small>
		<div class="pull-right">
			<a href="darel_data.php" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-chevron-left"></i> Kembali</a>
		</div>
	</h4>
	<div class="row">
		<div class="col-lg-6 col-lg-offset-3">
			<?php
			$id = @$_GET['id'];
			$sql_dokter = mysqli_query($con, "SELECT * FROM darel_tb_user WHERE darel_id_user='$id'") or die(mysqli_error($con));
			$data = mysqli_fetch_array($sql_dokter);
			?>
			<form action="darel_proses.php" method="post">
				<div class="form-group">
					<label for="nama">Nama Dokter</label>
					<input type="hidden" name="id" value="<?= $data['darel_id_user'] ?>">
					<input type="text" name="nama" id="nama" value="<?= $data['darel_nama_user'] ?>" class="form-control" required="" autofocus="">
				</div>
				<div class="form-group">
					<label for="">Level</label>
					<div>
						<label class="radio-inline">
							<input type="radio" name="level" value="1" required=""  <?= $data['darel_level'] == '1' ?  'checked' : ''; ?>> Admin
						</label>
						<label class="radio-inline">
							<input type="radio" name="level" value="2" <?= $data['darel_level'] == '2' ?  'checked' : ''; ?>> User
						</label>
					</div>
				</div>
				<div class="form-group">
					<label for="spesialis">Username</label>
					<input type="text" name="username" id="username" value="<?= $data['darel_username'] ?>" class="form-control" required="">
				</div>
				<div class="form-group">
					<input type="submit" name="edit" value="Simpan" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>
</div>

<?php include_once('../darel_footer.php'); ?>
