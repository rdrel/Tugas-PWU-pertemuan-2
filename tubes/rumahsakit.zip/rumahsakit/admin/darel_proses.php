<?php
require_once"../_config/darel_config.php";
require "../_assets/libs/vendor/autoload.php";

use Ramsey\Uuid\Uuid;

if(isset($_POST['add'])){
	$uuid = Uuid::uuid4()->toString();
	$nama = trim(mysqli_real_escape_string($con, $_POST['nama']));
	$level = trim(mysqli_real_escape_string($con, $_POST['level']));
	$username = trim(mysqli_real_escape_string($con, $_POST['username']));
	$password = md5(trim(mysqli_real_escape_string($con, $_POST['password'])));
	mysqli_query($con, "INSERT INTO darel_tb_user VALUES('$uuid', '$nama', '$username', '$password', '$level')") or die(mysqli_error($con));
	echo "<script>alert('Data berhasil ditambahkan');window.location='darel_data.php';</script>";
}
else if(isset($_POST['edit'])){
	$id = $_POST['id'];
	$nama = trim(mysqli_real_escape_string($con, $_POST['nama']));
	$level = trim(mysqli_real_escape_string($con, $_POST['level']));
	$username = trim(mysqli_real_escape_string($con, $_POST['username']));
	mysqli_query($con, "UPDATE darel_tb_user SET darel_nama_user='$nama', darel_username='$username', darel_level='$level' WHERE darel_id_user='$id'") or die(mysqli_error($con));
	echo "<script>alert('Data berhasil diubah');window.location='darel_data.php';</script>";
}