<?php include_once('../darel_header.php'); ?>

<div class="box">
	<div class="col-lg-12 bg-black">
        <button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
    </div>
	<h1>Poliklinik</h1>
	<h4>
		<small>Tambah Data Poliklinik</small>
		<div class="pull-right">
			<a href="darel_data.php" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-chevron-left"></i> Kembali</a>
		</div>
	</h4>
	<div class="row">
		<div class="col-lg-6 col-lg-offset-3">
			<form action="darel_add.php" method="post">
				<div class="form-group">
					<label for="count_add">Banyaknya record yang akan ditambahkan</label>
					<input type="text" name="count_add" id="count_add" maxlength="2" pattern="[0-9]+" class="form-control" required="">
				</div>
				<div class="form-group">
					<input type="submit" name="generate" value="Generate" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>
</div>

<?php include_once('../darel_footer.php'); ?>