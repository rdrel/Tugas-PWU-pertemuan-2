<?php include_once('../darel_header.php'); ?>

<div class="box">
	<div class="col-lg-12 bg-black">
		<button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
	</div>
	<h1>Dokter</h1>
	<h4>
		<small>Data Dokter</small>
		<div class="pull-right">
				<?php if ($_SESSION['role'] == '1'): ?>
				<a href="" class="btn btn-default btn-xs"><i class="glyphicon glyphicon-refresh"></i></a>
				<a href="darel_add.php" class="btn btn-success btn-xs"><i class="glyphicon glyphicon-plus"></i> Tambah
					Dokter</a>
					<?php endif ?>
			</div>
	</h4>
	<form method="post" name="proses">
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover" id="dokter">
				<thead>
					<tr>
						<th>
								<?php if ($_SESSION['role'] == '1'): ?>
								<center>
									<input type="checkbox" id="select_all" value="">
								</center>
								<?php endif ?>
							</th>
						<th>No.</th>
						<th>Nama Dokter</th>
						<th>Spesialis</th>
						<th>Alamat</th>
						<th>No. Telepon</th>
						<th>
								<?php if ($_SESSION['role'] == '1'): ?>
								<i class="glyphicon glyphicon-cog"></i>
								<?php endif ?>
							</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$no = 1;
					$sql_poli = mysqli_query($con, "SELECT * FROM darel_tb_dokter");
					// var_dump($sql_poli);die;
					while ($data = mysqli_fetch_array($sql_poli)) { ?>
						<tr>
							<td align="center">
									<?php if ($_SESSION['role'] == '1'): ?>
									<input type="checkbox" name="checked[]" class="check"
										value="<?= $data['darel_id_dokter']; ?>">
										<?php endif ?>
								</td>
							<td>
								<?= $no++; ?>.
							</td>
							<td>
								<?= $data['darel_nama_dokter']; ?>
							</td>
							<td>
								<?= $data['darel_spesialis']; ?>
							</td>
							<td>
								<?= $data['darel_alamat']; ?>
							</td>
							<td>
								<?= $data['darel_no_telp']; ?>
							</td>
							<td align="center">
									<?php if ($_SESSION['role'] == '1'): ?>
									<a href="darel_edit.php?id=<?= $data['darel_id_dokter']; ?>"
										class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-edit"></i></a>
										<?php endif ?>
								</td>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</form>

	<div class="box">
		<?php if ($_SESSION['role'] == '1'): ?>
			<button class="btn btn-danger btn-sm" onclick="hapus()"><i class="glyphicon glyphicon-trash"></i> Hapus</button>
		<?php endif ?>
	</div>

</div>

<script>
	$(function () {

		$('#dokter').DataTable({
			columnDefs: [{
				"searchable": false,
				"orderable": false,
				"targets": [0, 6]
			}],
			"order": [1, "asc"]
		});

		$('#select_all').on('click', function () {
			if (this.checked) {
				$('.check').each(function () {
					this.checked = true;
				})
			}
			else {
				$('.check').each(function () {
					this.checked = false;
				})
			}
		});
		$('.check').on('click', function () {
			if ($('.check:checked').length == $('.check').length) {
				$('#select_all').prop('checked', true)
			}
			else {
				$('#select_all').prop('checked', false)
			}
		})
	});

	function hapus() {
		var conf = confirm('Yakin akan menghapus data?');
		if (conf) {
			document.proses.action = 'darel_del.php';
			document.proses.submit();
		}
	};

</script>


<?php include_once('../darel_footer.php'); ?>