<?php include_once('../darel_header.php'); ?>

<div class="box">
	<div class="col-lg-12 bg-black">
		<button href="#menu-toggle" class="btn btn-default" id="menu-toggle">≡</button>
	</div>
	<h1>Pengguna Aplikasi</h1>
	<h4>
		<small>Data Admin/User</small>
		<?php if ($_SESSION['role'] == '1'): ?>
			<div class="pull-right">
				<a href="" class="btn btn-default btn-xs"><i class="glyphicon glyphicon-refresh"></i></a>
				<a href="darel_add.php" class="btn btn-success btn-xs"><i class="glyphicon glyphicon-plus"></i> Tambah
					Admin/User</a>
			</div>
		<?php endif ?>
	</h4>
	<form method="post" name="proses">
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover" id="dokter">
				<thead>
					<tr>
						<?php if ($_SESSION['role'] == '1'): ?>
							<th>
								<center>
									<input type="checkbox" id="select_all" value="">
								</center>
							</th>
						<?php endif ?>
						<th>No.</th>
						<th>Nama</th>
						<th>Username</th>
						<th>Role</th>
						<?php if ($_SESSION['role'] == '1'): ?>
							<th><i class="glyphicon glyphicon-cog"></i></th>
						<?php endif ?>
					</tr>
				</thead>
				<tbody>
					<?php
					$no = 1;
					$sql_poli = mysqli_query($con, "SELECT * FROM darel_tb_user");
					// var_dump($sql_poli);die;
					while ($data = mysqli_fetch_array($sql_poli)) { ?>
						<tr>
							<?php if ($_SESSION['role'] == '1'): ?>
								<td align="center">
									<input type="checkbox" name="checked[]" class="check"
										value="<?= $data['darel_id_user']; ?>">
								</td>
							<?php endif ?>
							<td>
								<?= $no++; ?>.
							</td>
							<td>
								<?= $data['darel_nama_user']; ?>
							</td>
							<td>
								<?= $data['darel_username']; ?>
							</td>
							<td>
								<?= $data['darel_level'] == '1' ?  'Admin' : 'User'; ?>
							</td>
							<?php if ($_SESSION['role'] == '1'): ?>
								<td align="center">
									<a href="darel_edit.php?id=<?= $data['darel_id_user']; ?>"
										class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-edit"></i></a>
								</td>
							<?php endif ?>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</form>

	<div class="box">
		<?php if ($_SESSION['role'] == '1'): ?>
			<button class="btn btn-danger btn-sm" onclick="hapus()"><i class="glyphicon glyphicon-trash"></i> Hapus</button>
		<?php endif ?>
	</div>

</div>

<script>
	$(function () {

		$('#dokter').DataTable({
			columnDefs: [{
				"searchable": false,
				"orderable": false,
				"targets": [0, 6]
			}],
			"order": [1, "asc"]
		});

		$('#select_all').on('click', function () {
			if (this.checked) {
				$('.check').each(function () {
					this.checked = true;
				})
			}
			else {
				$('.check').each(function () {
					this.checked = false;
				})
			}
		});
		$('.check').on('click', function () {
			if ($('.check:checked').length == $('.check').length) {
				$('#select_all').prop('checked', true)
			}
			else {
				$('#select_all').prop('checked', false)
			}
		})
	});

	function hapus() {
		var conf = confirm('Yakin akan menghapus data?');
		if (conf) {
			document.proses.action = 'darel_del.php';
			document.proses.submit();
		}
	};

</script>


<?php include_once('../darel_footer.php'); ?>