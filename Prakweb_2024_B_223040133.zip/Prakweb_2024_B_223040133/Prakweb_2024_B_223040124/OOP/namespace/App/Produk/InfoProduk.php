<?php 

interface infoProduk {
  public function getInfoProduk();
}